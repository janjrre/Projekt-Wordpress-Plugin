<?php
/**
 * Privacy subject lookup, tenant-safe export pages and conservative redaction.
 *
 * @package UOP
 */

namespace UOP\Infrastructure\Database;

use RuntimeException;
use UOP\Core\PublicId;

/** An email is not a person key. Only explicit WordPress account links identify subjects. */
final class PrivacyAccountGateway {
	/**
	 * Bind the live site-scoped database.
	 *
	 * @param Connection $db     Active database adapter.
	 * @param string     $prefix Trusted site table prefix.
	 */
	public function __construct( private Connection $db, private string $prefix ) {}

	/**
	 * Resolve a verified WordPress privacy-request email without family data mixing.
	 *
	 * @param string $email WordPress request email.
	 * @return array{status:string,user_id:int} Resolution status and user ID only.
	 */
	public function resolve( string $email ): array {
		if ( ! is_email( $email ) ) {
			return $this->resolution( 'unmatched', 0 );
		}
		$user   = get_user_by( 'email', $email );
		$userid = $user instanceof \WP_User ? (int) $user->ID : 0;
		$linked = 0;
		if ( $userid > 0 ) {
			$rows   = $this->db->rows(
				'SELECT id FROM %i WHERE wp_user_id = %d ORDER BY id ASC LIMIT 101',
				array( $this->prefix . 'persons', $userid )
			);
			$linked = count( $rows );
			if ( $linked > 100 ) {
				return $this->resolution( 'manual', 0 );
			}
		}
		$other = $this->db->rows(
			'SELECT id FROM %i WHERE primary_email = %s AND (wp_user_id IS NULL OR wp_user_id <> %d) LIMIT 1',
			array( $this->prefix . 'persons', $email, $userid )
		);
		if ( $other ) {
			return $this->resolution( 'manual', 0 );
		}
		$other_registration = $this->db->rows(
			'SELECT r.id FROM %i r INNER JOIN %i p ON p.id = r.person_id AND p.organization_id = r.organization_id WHERE r.contact_email = %s AND (p.wp_user_id IS NULL OR p.wp_user_id <> %d) LIMIT 1',
			array( $this->prefix . 'registrations', $this->prefix . 'persons', $email, $userid )
		);
		if ( $other_registration ) {
			return $this->resolution( 'manual', 0 );
		}
		$other_mail = $this->db->rows(
			'SELECT m.id FROM %i m LEFT JOIN %i r ON r.id = m.registration_id AND r.organization_id = m.organization_id LEFT JOIN %i p ON p.id = r.person_id AND p.organization_id = r.organization_id WHERE m.recipient = %s AND (p.id IS NULL OR p.wp_user_id IS NULL OR p.wp_user_id <> %d) LIMIT 1',
			array( $this->prefix . 'email_messages', $this->prefix . 'registrations', $this->prefix . 'persons', $email, $userid )
		);
		if ( $other_mail ) {
			return $this->resolution( 'manual', 0 );
		}
		return $this->resolution( $linked > 0 ? 'resolved' : 'unmatched', $userid );
	}

	/**
	 * Read bounded, account-linked privacy data without selecting delegated subjects.
	 *
	 * @param int $user_id Trusted WordPress account.
	 * @param int $page    One-based WordPress privacy page.
	 * @return array{data:list<array<string,mixed>>,done:bool}
	 * @throws RuntimeException If stored historic evidence fails integrity validation.
	 */
	public function export_page( int $user_id, int $page ): array {
		if ( $user_id < 1 || $page < 1 || $page > 100000 ) {
			return $this->export_result( array(), true );
		}
		$limit = 25;
		$after = ( $page - 1 ) * $limit;
		$data  = array();
		$done  = true;
		$rows  = $this->db->rows(
			'SELECT id, public_id, organization_id, display_name, primary_email, status, created_at FROM %i WHERE wp_user_id = %d ORDER BY id ASC LIMIT %d OFFSET %d',
			array( $this->prefix . 'persons', $user_id, $limit, $after )
		);
		$done  = count( $rows ) < $limit;
		foreach ( $rows as $row ) {
			$data[] = $this->item(
				'uop-person',
				'UOP person',
				PublicId::from_binary( $row['public_id'] )->to_string(),
				array(
					$this->datum( 'Organization', (string) $row['organization_id'] ),
					$this->datum( 'Display name', (string) $row['display_name'] ),
					$this->datum( 'Contact email', (string) ( $row['primary_email'] ?? '' ) ),
					$this->datum( 'Status', (string) $row['status'] ),
					$this->datum( 'Created', (string) $row['created_at'] ),
				)
			);
		}

		$values = $this->db->rows(
			'SELECT v.id, v.ordinal, v.value_string, v.value_text, v.value_integer, v.value_decimal, v.value_date, v.value_datetime, v.value_boolean, f.label, p.public_id FROM %i v INNER JOIN %i p ON p.id = v.person_id INNER JOIN %i f ON f.id = v.field_id AND f.organization_id = p.organization_id WHERE p.wp_user_id = %d ORDER BY v.id ASC LIMIT %d OFFSET %d',
			array( $this->prefix . 'profile_values', $this->prefix . 'persons', $this->prefix . 'profile_fields', $user_id, $limit, $after )
		);
		$done   = $done && count( $values ) < $limit;
		foreach ( $values as $row ) {
			$value = '';
			foreach ( array( 'value_string', 'value_text', 'value_integer', 'value_decimal', 'value_date', 'value_datetime', 'value_boolean' ) as $slot ) {
				if ( null !== $row[ $slot ] ) {
					$value = (string) $row[ $slot ];
					break;
				}
			}
			$data[] = $this->item(
				'uop-profile',
				'UOP profile values',
				(string) $row['id'],
				array(
					$this->datum( 'Person', PublicId::from_binary( $row['public_id'] )->to_string() ),
					$this->datum( 'Field', (string) $row['label'] ),
					$this->datum( 'Value', $value ),
				)
			);
		}

		$snapshots = $this->db->rows(
			'SELECT s.id, s.payload_json, s.payload_hash, s.redacted_at, s.revision, r.public_id AS registration_public_id, r.status, r.contact_email, r.event_post_id FROM %i s INNER JOIN %i r ON r.id = s.registration_id INNER JOIN %i p ON p.id = r.person_id AND p.organization_id = r.organization_id WHERE p.wp_user_id = %d ORDER BY s.id ASC LIMIT %d OFFSET %d',
			array( $this->prefix . 'registration_snapshots', $this->prefix . 'registrations', $this->prefix . 'persons', $user_id, $limit, $after )
		);
		$done      = $done && count( $snapshots ) < $limit;
		foreach ( $snapshots as $row ) {
			if ( null === $row['redacted_at'] && ! hash_equals( (string) $row['payload_hash'], hash( 'sha256', (string) $row['payload_json'], true ) ) ) {
				throw new RuntimeException( 'Stored registration history integrity violation.' );
			}
			$data[] = $this->item(
				'uop-registration',
				'UOP registrations',
				(string) $row['id'],
				array(
					$this->datum( 'Registration', PublicId::from_binary( $row['registration_public_id'] )->to_string() ),
					$this->datum( 'Revision', (string) $row['revision'] ),
					$this->datum( 'Status', (string) $row['status'] ),
					$this->datum( 'Event', (string) $row['event_post_id'] ),
					$this->datum( 'Contact email', (string) ( $row['contact_email'] ?? '' ) ),
					$this->datum( 'Answers', null === $row['redacted_at'] ? (string) $row['payload_json'] : '[redacted]' ),
				)
			);
		}

		$consents = $this->db->rows(
			'SELECT c.id, c.public_id, c.decision, c.auth_context, c.decided_at, v.version, d.consent_key FROM %i c INNER JOIN %i p ON p.id = c.subject_person_id AND p.organization_id = c.organization_id INNER JOIN %i v ON v.id = c.definition_version_id INNER JOIN %i d ON d.id = v.definition_id AND d.organization_id = c.organization_id WHERE p.wp_user_id = %d ORDER BY c.id ASC LIMIT %d OFFSET %d',
			array( $this->prefix . 'consent_records', $this->prefix . 'persons', $this->prefix . 'consent_versions', $this->prefix . 'consent_definitions', $user_id, $limit, $after )
		);
		$done     = $done && count( $consents ) < $limit;
		foreach ( $consents as $row ) {
			$data[] = $this->item(
				'uop-consent',
				'UOP consent evidence',
				PublicId::from_binary( $row['public_id'] )->to_string(),
				array(
					$this->datum( 'Definition', (string) $row['consent_key'] ),
					$this->datum( 'Version', (string) $row['version'] ),
					$this->datum( 'Decision', (string) $row['decision'] ),
					$this->datum( 'Acting context', (string) $row['auth_context'] ),
					$this->datum( 'Decided', (string) $row['decided_at'] ),
				)
			);
		}

		// Export only the authenticated account's explicitly linked subjects;
		// an age proof is distinct from a guardian's delegated subjects.
		$age_records = $this->db->rows(
			'SELECT a.public_id, a.event_post_id, a.threshold_age, a.outcome, a.status, a.method_key, a.checked_at, a.valid_until FROM %i a INNER JOIN %i p ON p.id = a.person_id AND p.organization_id = a.organization_id WHERE p.wp_user_id = %d ORDER BY a.id ASC LIMIT %d OFFSET %d',
			array( $this->prefix . 'age_attestations', $this->prefix . 'persons', $user_id, $limit, $after )
		);
		$done        = $done && count( $age_records ) < $limit;
		foreach ( $age_records as $row ) {
			$data[] = $this->item(
				'uop-age-attestation',
				'UOP age category evidence',
				PublicId::from_binary( (string) $row['public_id'] )->to_string(),
				array(
					$this->datum( 'Event', (string) $row['event_post_id'] ),
					$this->datum( 'Threshold', (string) $row['threshold_age'] ),
					$this->datum( 'Category', (string) $row['outcome'] ),
					$this->datum( 'Status', (string) $row['status'] ),
					$this->datum( 'Method', (string) $row['method_key'] ),
					$this->datum( 'Checked', (string) $row['checked_at'] ),
					$this->datum( 'Valid until', (string) $row['valid_until'] ),
				)
			);
		}

		$messages = $this->db->rows(
			'SELECT m.id, m.public_id, m.template_key, m.status, m.queued_at, m.recipient FROM %i m INNER JOIN %i r ON r.id = m.registration_id AND r.organization_id = m.organization_id INNER JOIN %i p ON p.id = r.person_id AND p.organization_id = r.organization_id WHERE p.wp_user_id = %d ORDER BY m.id ASC LIMIT %d OFFSET %d',
			array( $this->prefix . 'email_messages', $this->prefix . 'registrations', $this->prefix . 'persons', $user_id, $limit, $after )
		);
		$done     = $done && count( $messages ) < $limit;
		foreach ( $messages as $row ) {
			$data[] = $this->item(
				'uop-mail',
				'UOP communications',
				PublicId::from_binary( $row['public_id'] )->to_string(),
				array(
					$this->datum( 'Template', (string) $row['template_key'] ),
					$this->datum( 'Recipient', (string) $row['recipient'] ),
					$this->datum( 'Status', (string) $row['status'] ),
					$this->datum( 'Queued', (string) $row['queued_at'] ),
				)
			);
		}
		return $this->export_result( $data, $done );
	}

	/**
	 * Redact active profile and person contact values, preserving historical evidence.
	 *
	 * @param int $user_id Explicitly resolved WordPress account.
	 * @return list<array{id:int,organization_id:int}> Subjects with altered values.
	 */
	public function erase_contact_profile( int $user_id ): array {
		$rows = $this->db->rows(
			'SELECT id, organization_id FROM %i WHERE wp_user_id = %d ORDER BY id LIMIT 101 FOR UPDATE',
			array( $this->prefix . 'persons', $user_id )
		);
		if ( ! $rows || count( $rows ) > 100 ) {
			return array();
		}
		$removed = array();
		foreach ( $rows as $person ) {
			$id                = (int) $person['id'];
			$org               = (int) $person['organization_id'];
			$hold              = $this->db->rows(
				'SELECT id FROM %i WHERE id = %d AND organization_id = %d AND retention_hold_until > UTC_TIMESTAMP() LIMIT 1',
				array( $this->prefix . 'persons', $id, $org )
			);
			$registration_hold = $this->db->rows(
				'SELECT id FROM %i WHERE person_id = %d AND organization_id = %d AND retention_hold_until > UTC_TIMESTAMP() LIMIT 1',
				array( $this->prefix . 'registrations', $id, $org )
			);
			if ( $hold || $registration_hold ) {
				continue;
			}
			$deleted = $this->db->execute(
				'DELETE v FROM %i v INNER JOIN %i p ON p.id = v.person_id WHERE p.organization_id = %d AND p.id = %d AND p.wp_user_id = %d',
				array( $this->prefix . 'profile_values', $this->prefix . 'persons', $org, $id, $user_id )
			);
			// A permitted account erasure also destroys its event-specific age
			// threshold evidence; never change other linked/delegated persons.
			$age_deleted = $this->db->execute(
				'DELETE a FROM %i a INNER JOIN %i p ON p.id = a.person_id AND p.organization_id = a.organization_id WHERE p.organization_id = %d AND p.id = %d AND p.wp_user_id = %d',
				array( $this->prefix . 'age_attestations', $this->prefix . 'persons', $org, $id, $user_id )
			);
			$updated     = $this->db->execute(
				'UPDATE %i SET display_name = %s, primary_email = NULL, version = version + 1, updated_at = UTC_TIMESTAMP() WHERE organization_id = %d AND id = %d AND wp_user_id = %d AND (display_name <> %s OR primary_email IS NOT NULL)',
				array( $this->prefix . 'persons', 'Erased person', $org, $id, $user_id, 'Erased person' )
			);
			if ( $deleted > 0 || $age_deleted > 0 || $updated > 0 ) {
				$removed[] = array(
					'id'              => $id,
					'organization_id' => $org,
				);
			}
		}
		return $removed;
	}

	/**
	 * Format one WordPress privacy exporter datum without HTML injection.
	 *
	 * @param string $group Group slug.
	 * @param string $label Group title.
	 * @param string $id    Stable item ID.
	 * @param array  $data  Named text values.
	 * @phpstan-param list<array{name:string,value:string}> $data
	 * @return array<string, mixed> WordPress privacy item.
	 */
	private function item( string $group, string $label, string $id, array $data ): array {
		return array(
			'group_id'    => $group,
			'group_label' => $label,
			'item_id'     => $id,
			'data'        => $data,
		);
	}
	/**
	 * Create one consistent WordPress privacy field.
	 *
	 * @param string $name  Human-readable label.
	 * @param string $value Plain-text data.
	 * @return array{name:string,value:string}
	 */
	private function datum( string $name, string $value ): array {
		return array(
			'name'  => $name,
			'value' => $value,
		);
	}

	/**
	 * Format one account-resolution result.
	 *
	 * @param string $status  Resolved, manual or unmatched.
	 * @param int    $user_id Account ID when resolved.
	 * @return array{status:string,user_id:int}
	 */
	private function resolution( string $status, int $user_id ): array {
		return array(
			'status'  => $status,
			'user_id' => $user_id,
		);
	}

	/**
	 * Format the WordPress exporter response.
	 *
	 * @param array $data Bounded privacy data.
	 * @phpstan-param list<array<string,mixed>> $data
	 * @param bool  $done Whether all pages have been processed.
	 * @return array{data:list<array<string,mixed>>,done:bool}
	 */
	private function export_result( array $data, bool $done ): array {
		return array(
			'data' => $data,
			'done' => $done,
		);
	}
}
